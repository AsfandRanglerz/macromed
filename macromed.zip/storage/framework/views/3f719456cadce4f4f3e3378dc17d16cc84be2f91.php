<!DOCTYPE html>
<html lang="en">
<!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->

<head>
    <meta charset="UTF-8">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, shrink-to-fit=no" name="viewport">
    <title>Macromed | <?php echo $__env->yieldContent('title'); ?></title>
    <!-- General CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/app.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/bundles/bootstrap-social/bootstrap-social.css')); ?>">
    <!-- Template CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/components.css')); ?>">
    <!-- Custom style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/assets/css/custom.css')); ?>">
    <link rel='shortcut icon' type='image/x-icon' href='<?php echo e(asset('public/admin/assets/images/Favicon-02.png')); ?>' />
    <link rel="stylesheet" href="<?php echo e(asset('public/admin/toastr/toastr.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>

<body>
    <div class="loader"></div>
    <div id="app">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- General JS Scripts -->
    <script src="<?php echo e(asset('public/admin/assets/js/app.min.js')); ?>"></script>
    <!-- Template JS File -->
    <script src="<?php echo e(asset('public/admin/assets/js/scripts.js')); ?>"></script>
    <!-- Custom JS File -->
    <script src="<?php echo e(asset('public/admin/assets/js/custom.js')); ?>"></script>
    <!-- Sweet Alert -->
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?php echo e(asset('public/admin/toastr/toastr.js')); ?>"></script>
</body>
<!-- auth-login.html  21 Nov 2019 03:49:32 GMT -->
<?php echo $__env->yieldContent('script'); ?>
<script>
    toastr.options = {
        "closeButton": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "timeOut": 1000,
        "extendedTimeOut": 1000
    };

    <?php if(session('message')): ?>
        toastr.success("<?php echo e(session('message')); ?>");
    <?php endif; ?>

    <?php if(session('error')): ?>
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(session('info')): ?>
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(session('warning')): ?>
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>

</html>
<?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/admin/auth/layout/app.blade.php ENDPATH**/ ?>