<?php $__env->startSection('title', 'Login'); ?>
<?php $__env->startSection('content'); ?>
    <section class="section">
        <div class="container mt-5">
            <div class="row">
                <div class="col-12 col-sm-8 offset-sm-2 col-md-6 offset-md-3 col-lg-6 offset-lg-3 col-xl-4 offset-xl-4">
                    <div class="card card-primary">
                        <div class="text-center mt-1">
                            <img alt="image" src="<?php echo e(asset('public/admin/assets/images/logo-macromed.png')); ?>"
                                style="width: 40%" />
                        </div>
                        <div class="card-body">
                            <form method="POST" action="<?php echo e(url('sales-agent/login')); ?>" class="needs-validation"
                                novalidate="">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input id="email" type="email" class="form-control" name="email" tabindex="1"
                                        required autofocus name="email">
                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger">Email required</span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <label for="password" class="control-label">Password</label>
                                    <div class="position-relative">
                                        <input id="password" type="password" class="form-control" name="password"
                                            tabindex="2" required name="password">
                                        <span class="position-absolute eye-icon-set" style="cursor: pointer;">
                                            <i id="eye" class="eye-height" data-feather="eye-off"></i>
                                        </span>
                                    </div>
                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="form-group">
                                    <div class="custom-control custom-checkbox">
                                        
                                        <div class="d-block">
                                            
                                            <div class="float-right">
                                                <a href="<?php echo e(url('salesAgent-forgot-password')); ?>" class="text-small">
                                                    Forgot Password?
                                                </a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group mb-0">
                                    <button type="submit" class="btn btn-primary btn-lg btn-block btn-login" tabindex="4">
                                        Login
                                    </button>
                                </div>
                            </form>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function () {
        $('.btn-login').on('click', function () {
           $('.eye-icon-set').addClass('d-none');
        });
        feather.replace();

        $('.eye-icon-set').on('click', function () {
            const passwordField = $('#password');
            const icon = $('#eye');

            if (passwordField.attr('type') === 'password') {
                passwordField.attr('type', 'text');
                icon.attr('data-feather', 'eye');
            } else {
                passwordField.attr('type', 'password');
                icon.attr('data-feather', 'eye-off');
            }

            feather.replace();
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('salesagent.auth.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/salesagent/auth/login.blade.php ENDPATH**/ ?>