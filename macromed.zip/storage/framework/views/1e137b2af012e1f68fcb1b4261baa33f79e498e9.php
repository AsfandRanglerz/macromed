<footer class="main-footer">
    <div class="footer-left">
        <p>Powered By <a href="https://macromed.com.pk/" style="color:#fff !important">Macromed</a></p>
    </div>
    <div class="footer-right">
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/admin/common/footer.blade.php ENDPATH**/ ?>