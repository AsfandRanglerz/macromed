
<?php $__env->startSection('title', 'History'); ?>
<?php $__env->startSection('content'); ?>

    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-12 col-md-12 col-lg-12">
                        <a class="btn btn-primary mb-3" href="<?php echo e(route('salesagent.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header">
                                <div class="col-12">
                                    <h4>Withdrawal History</h4>
                                </div>

                            </div>

                            <div class="card-body table-responsive">
                                <div class="row">
                                    <div class="col-md-3">
                                        <h5 class="text-muted">Total Amount</h5>
                                        <p class="font-weight-bold">
                                            PKR <?php echo e(number_format($walletHistory->total_commission, 2)); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <h5 class="text-muted">Pending Amount</h5>
                                        <p class="font-weight-bold">
                                            PKR <?php echo e(number_format($walletHistory->pending_commission, 2)); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <h5 class="text-muted">Received Amount</h5>
                                        <p class="font-weight-bold">
                                            PKR <?php echo e(number_format($walletHistory->recevied_commission, 2)); ?></p>
                                    </div>
                                    <div class="col-md-3">
                                        <h5 class="text-muted">Withdraw Amount</h5>
                                        <p class="font-weight-bold">
                                            PKR <?php echo e(number_format($walletHistory->with_drawal_amount, 2)); ?></p>
                                    </div>
                                </div>

                                <table class="responsive datatables-basic table border-top  table" id="table-1">
                                    <thead>
                                        <tr>
                                            <th>Sr.</th>
                                            <th>Amount</th>
                                            <th>Status</th>
                                            <th>Date</th>
                                            <th>Transaction proof</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $paymentRequests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paymentRequest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($loop->iteration); ?></td>
                                                <td>$<?php echo e($paymentRequest->amount); ?>

                                                </td>
                                                <td
                                                    class="<?php echo e($paymentRequest->status == 'approved' ? 'text-success' : 'text-danger'); ?>">
                                                    <?php echo e($paymentRequest->status == 'approved' ? 'Paid' : 'Pending'); ?>

                                                </td>
                                                <td><?php echo e($paymentRequest->created_at->format('d-m-Y')); ?></td>
                                                <td>
                                                    <div id="aniimated-thumbnials" class=" clearfix">
                                                        <div class="col-lg-3 col-md-4 col-sm-6 col-xs-12">
                                                            <a href="<?php echo e(asset($paymentRequest->image)); ?>"
                                                                data-sub-html="Payment Proof Image">
                                                                <img src="<?php echo e(asset($paymentRequest->image)); ?>"
                                                                    class="img-responsive thumbnail"
                                                                    alt="Payment Proof Image"
                                                                    style="max-width: 100px; max-height: 100px;">
                                                            </a>
                                                        </div>
                                                    </div>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


<?php $__env->startSection('js'); ?>
    


<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/admin/salesagent/paymentHistory.blade.php ENDPATH**/ ?>