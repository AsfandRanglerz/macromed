<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="#"> <img alt="image" src="<?php echo e(asset('public/admin/assets/images/logo-macromed.png')); ?>"
                    style="width: 40%" />
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            
            <li class="dropdown <?php echo e(request()->is('admin/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/admin/dashboard')); ?>" class="nav-link"><i
                        data-feather="home"></i><span>Dashboard</span></a>
            </li>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Sliders')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/silder-image') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/silder-image')); ?>" class="nav-link"><i
                            data-feather="image"></i><span>Sliders</span></a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/silder-image') ? 'active' : ''); ?>">
                    <a href="<?php echo e(url('/admin/silder-image')); ?>" class="nav-link"><i
                            data-feather="image"></i><span>Sliders</span></a>
                </li>
            <?php endif; ?>
            
            <?php if(
                (auth()->guard('web')->check() &&
                    (auth()->guard('web')->user()->can('Category') ||
                        auth()->guard('web')->user()->can('Sub Category') ||
                        auth()->guard('web')->user()->can('Brands') ||
                        auth()->guard('web')->user()->can('Company') ||
                        auth()->guard('web')->user()->can('Models') ||
                        auth()->guard('web')->user()->can('Units') ||
                        auth()->guard('web')->user()->can('PackingValues') ||
                        auth()->guard('web')->user()->can('Sterilization') ||
                        auth()->guard('web')->user()->can('Number Of Use') ||
                        auth()->guard('web')->user()->can('Supplier') ||
                        auth()->guard('web')->user()->can('Main Material') ||
                        auth()->guard('web')->user()->can('Products') ||
                        auth()->guard('web')->user()->can('Certification'))) ||
                    auth()->guard('admin')->check()): ?>
                <li class="dropdown">
                    <a href="#" class="menu-toggle nav-link has-dropdown"><i
                            data-feather="layout"></i><span>Inventory
                            Managment</span></a>
                    <ul
                        class="dropdown-menu <?php echo e(request()->is('admin/number-of-use*') || request()->is('admin/category*') || request()->is('admin/subCategory*') || request()->is('admin/brands*') || request()->is('admin/product*') || request()->is('admin/company*') || request()->is('admin/models*') || request()->is('admin/certification*') || request()->is('admin/units*')|| request()->is('admin/PackingValues*') || request()->is('admin/sterilization*') || request()->is('admin/supplier*') || request()->is('admin/mainMaterial*') ? 'show' : ''); ?>">
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Category')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/category*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('category.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/category*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Category</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/category*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('category.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/category*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Category</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Sub Category')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/subCategory*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('subCategory.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/subCategory*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Sub Category</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/subCategory*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('subCategory.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/subCategory*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Sub Category</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Brands')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/brands*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('brands.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/brands*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Brands</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/brands*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('brands.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/brands*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Brands</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Company')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/company*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('company.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/company*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Company</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/company*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('company.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/company*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Company</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Certification')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/certification*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('certification.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/certification*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Certifications</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/certification*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('certification.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/certification*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Certifications</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Units')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/units*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('units.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/units*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Units</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/units*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('units.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/units*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Units</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('PackingValue')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/PackingValue*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('PackingValue.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/PackingValue*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>PackingValues</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/PackingValue*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('PackingValue.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/PackingValue*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>PackingValues</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Sterilization')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/sterilization*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('sterilization.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/sterilization*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Sterilization</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/sterilization*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('sterilization.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/sterilization*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Sterilization</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Number Of Use')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/number-of-use*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('numberOfUse.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/number-of-use*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Number Of Use</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/number-of-use*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('numberOfUse.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/number-of-use*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Number Of Use</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Supplier')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/supplier*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('supplier.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/supplier*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Suppliers</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/supplier*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('supplier.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/supplier*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Suppliers</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Main Material')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/mainMaterial*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('mainMaterial.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/mainMaterial*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Main Materials</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/mainMaterial*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('mainMaterial.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/mainMaterial*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Main Materials</span>
                                </a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Products')): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/product*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('product.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/product*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Products</span>
                                </a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="dropdown <?php echo e(request()->is('admin/product*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('product.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/product*') ? 'text-white' : ''); ?>">
                                    <i data-feather="layers"></i><span>Products</span>
                                </a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            
            <?php if(
                (auth()->guard('web')->check() &&
                    (auth()->guard('web')->user()->can('Sub Admin') ||
                        auth()->guard('web')->user()->can('Customer') ||
                        auth()->guard('web')->user()->can('Sales Agent'))) ||
                    auth()->guard('admin')->check()): ?>
                <li class="dropdown">
                    <a href="#" class="menu-toggle nav-link has-dropdown"><i
                            data-feather="users"></i><span>User
                            Managment</span></a>
                    <ul
                        class="dropdown-menu <?php echo e(request()->is('admin/subadmin*') || request()->is('admin/customer*') || request()->is('admin/salesagent*') ? 'show' : ''); ?>">
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Sub Admin')): ?>
                            <li class="<?php echo e(request()->is('admin/subadmin') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('subadmin.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/subadmin') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Sub
                                        Admins</span></a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="<?php echo e(request()->is('admin/subadmin*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('subadmin.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/subadmin*') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Sub
                                        Admins</span></a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Sales Agent')): ?>
                            <li class="<?php echo e(request()->is('admin/salesagent*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('salesagent.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/salesagent*') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Sales Managers</span></a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="<?php echo e(request()->is('admin/salesagent*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('salesagent.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/salesagent*') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Sales Managers</span></a>
                            </li>
                        <?php endif; ?>
                        
                        <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Customer')): ?>
                            <li class="<?php echo e(request()->is('admin/customer*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('customer.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/customer*') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Customers</span></a>
                            </li>
                        <?php elseif(auth()->guard('admin')->check()): ?>
                            <li class="<?php echo e(request()->is('admin/customer*') ? 'active' : ''); ?>">
                                <a href="<?php echo e(route('customer.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/customer*') ? 'text-white' : ''); ?>"><i
                                        data-feather="user"></i><span>Customers</span></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Orders')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/order*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('order.index')); ?>" class="nav-link padding" style="padding-left: 23px">
                        <span><i data-feather="shopping-cart"></i>
                            Orders</span>
                        <div id="orderCounter"
                            class="badge <?php echo e(request()->is('admin/order*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/order*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('order.index')); ?>" class="nav-link padding" style="padding-left: 23px">
                        <span> <i data-feather="shopping-cart"></i>
                            Orders</span>
                        <div id="orderCounter"
                            class="badge <?php echo e(request()->is('admin/order*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Discount Codes')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/discountsCode*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('discountsCode.index')); ?>" class="nav-link" style="padding-left:23px">
                        <span><i data-feather="percent"></i>Discount Codes</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/discountsCode*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('discountsCode.index')); ?>" class="nav-link" style="padding-left:23px">
                        <span> <i data-feather="percent"></i>
                            Discount Codes</span>
                    </a>
                </li>
            <?php endif; ?>

            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Reports')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/reports*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('reports.index')); ?>" class="nav-link" style="padding-left:23px">
                        <span><i data-feather="file-text"></i>Reports</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/reports*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('reports.index')); ?>" class="nav-link" style="padding-left:23px">
                        <span> <i data-feather="file-text"></i>
                            Reports</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Withdrawal Requests')): ?>
                <li class="<?php echo e(request()->is('admin/paymentRequest*') ? 'active' : ''); ?> ">
                    <a href="<?php echo e(route('paymentRequest.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/paymentRequest*') ? 'text-white' : ''); ?>"style="padding-left:13px">
                        <span> <i class="fas fa-coins"></i>Withdrawal Requests</span>
                        <div
                            class="badge paymentRequestCounter  <?php echo e(request()->is('admin/paymentRequest*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="<?php echo e(request()->is('admin/paymentRequest*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('paymentRequest.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/paymentRequest*') ? 'text-white' : ''); ?>"
                        style="padding-left:13px">
                        <span> <i class="fas fa-coins"></i>Withdrawal Requests</span>
                        <div
                            class="badge paymentRequestCounter  <?php echo e(request()->is('admin/paymentRequest*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                        </div>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Wallet WithDrawal Limit')): ?>
                <li class="<?php echo e(request()->is('admin/withdrawLimit*') ? 'active' : ''); ?> ">
                    <a href="<?php echo e(route('withdrawLimit.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/withdrawLimit*') ? 'text-white' : ''); ?>"style="padding-left:13px">
                        <span> <i class="fas fa-coins"></i>Wallet WithDrawal Limit</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="<?php echo e(request()->is('admin/withdrawLimit*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('withdrawLimit.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/withdrawLimit*') ? 'text-white' : ''); ?>"
                        style="padding-left:13px">
                        <span> <i class="fas fa-coins"></i>Wallet WithDrawal Limit</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Currency')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/currency*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('currency.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/currency*') ? 'text-white' : ''); ?>">
                        <span> <i data-feather="dollar-sign"></i>Currency</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/currency*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('currency.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/currency*') ? 'text-white' : ''); ?>">
                        <span><i data-feather="dollar-sign"></i>Currency</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Private Notes')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/privateNotes*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('privateNotes.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/privateNotes*') ? 'text-white' : ''); ?>">
                        <span><i data-feather="file"></i>Private Notes</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/privateNotes*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('privateNotes.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/privateNotes*') ? 'text-white' : ''); ?>">
                        <span><i data-feather="file"></i>Private Notes</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Notifications')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/adminNotification*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('adminNotification.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/adminNotification*') ? 'text-white' : ''); ?>">
                        <span><i data-feather="bell"></i>Notification</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/adminNotification*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('adminNotification.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/adminNotification*') ? 'text-white' : ''); ?>">
                        <span><i data-feather="bell"></i>Notification</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <li class="<?php echo e(request()->is('admin/blogs*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('blogs.index')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/blogs*') ? 'text-white' : ''); ?>"><i
                        data-feather="edit-3"></i><span>Blogs</span></a>
            </li>
            
            <li class="<?php echo e(request()->is('admin/career-section*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('careersection.index')); ?>"
                    class="nav-link <?php echo e(request()->is('admin/career-section*') ? 'text-white' : ''); ?>"><i
                        data-feather="briefcase"></i><span>Career Section</span></a>
            </li>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('About Us')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/about*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('about.index')); ?>" class="nav-link">
                        <span><i data-feather="info"></i>About Us</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/about*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('about.index')); ?>" class="nav-link">
                        <span><i data-feather="info"></i>About Us</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Privacy Policy')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/policy*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('policy.index')); ?>" class="nav-link">
                        <span> <i data-feather="shield"></i>Privacy Policy</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/policy*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('policy.index')); ?>" class="nav-link">
                        <span> <i data-feather="shield"></i>Privacy Policy</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('Terms & Conditions')): ?>
                <li class="dropdown <?php echo e(request()->is('admin/terms*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('terms.index')); ?>" class="nav-link">
                        <span> <i data-feather="file-text"></i>Terms & Conditions</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="dropdown <?php echo e(request()->is('admin/terms*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('terms.index')); ?>" class="nav-link">
                        <span> <i data-feather="file-text"></i>Terms & Conditions</span>
                    </a>
                </li>
            <?php endif; ?>
            
            <?php if(auth()->guard('web')->check() && auth()->guard('web')->user()->can('FAQ`s')): ?>
                <li class="<?php echo e(request()->is('admin/faq*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('faq.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/faq*') ? 'text-white' : ''); ?>">
                        <i data-feather="help-circle"></i>
                        <span>FAQ`s</span>
                    </a>
                </li>
            <?php elseif(auth()->guard('admin')->check()): ?>
                <li class="<?php echo e(request()->is('admin/faq*') ? 'active' : ''); ?>">
                    <a href="<?php echo e(route('faq.index')); ?>"
                        class="nav-link <?php echo e(request()->is('admin/faq*') ? 'text-white' : ''); ?>">
                        <i data-feather="help-circle"></i>
                        <span>FAQ`s</span>
                    </a>
                </li>
            <?php endif; ?>
        </ul>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/admin/common/side_menu.blade.php ENDPATH**/ ?>