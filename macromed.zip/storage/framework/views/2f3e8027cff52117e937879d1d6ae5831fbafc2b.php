<?php $__env->startSection('title', 'Product'); ?>
<?php $__env->startSection('content'); ?>
    
    <div class="main-content" style="min-height: 562px;">
        <section class="section">
            <div class="section-body">
                <div class="row">
                    <div class="col-md-12 col-md-12 col-lg-12">
                        <a class="btn btn-primary mb-3" href="<?php echo e(route('product.index')); ?>">Back</a>
                        <div class="card">
                            <div class="card-header">
                                <div class="col-md-12">
                                    <h4>Create Product</h4>
                                </div>
                            </div>
                            <div class="card-body">
                                <form id="productForm" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" id="draft_id" name="draft_id">
                                    <div class="form-group col-md-12">
                                        <label>Thumbnail Image Preview</label>
                                        <div>
                                            <img id="preview-img" class="admin-img"
                                                src="<?php echo e(asset('public/admin/assets/images/preview.png')); ?>"
                                                style="width: 15%" alt="Thumbnail Preview">
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Thumbnail Image</label>
                                        <input type="file" class="form-control-file" name="thumbnail_image"
                                            value="<?php echo e(old('thumbnail_image')); ?>" onchange="previewThumbnailImage(event)">
                                        <div class="invalid-feedback"></div>
                                    </div>
                                    <div class="form-group col-md-12">
                                        <label>PDF Preview</label>
                                        <div>
                                            <div id="pdf-preview"
                                                style="display: none; padding: 10px; border: 1px solid #ccc; width: 50%; background-color: #f9f9f9;">
                                                <i class="fas fa-file-pdf" style="font-size: 48px; color: red;"></i>
                                                <span id="pdf-name" style="margin-left: 10px; font-weight: bold;"></span>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-group col-md-6">
                                        <label>Upload PDF</label>
                                        <input type="file" class="form-control-file" name="pdf"
                                            accept="application/pdf" onchange="previewPDF(event)">
                                        <div class="invalid-feedback"></div>
                                    </div>

                                    <div class="row col-md-12">
                                        <div class="form-group col-md-4">
                                            <label>Product Short Name<span class="text-danger">*</span></label>
                                            <input type="text" id="short_name" class="form-control" name="short_name"
                                                value="<?php echo e(old('short_name')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Product Name<span class="text-danger">*</span></label>
                                            <input type="text" id="product_name" class="form-control name"
                                                name="product_name" value="<?php echo e(old('product_name')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Slug<span class="text-danger">*</span></label>
                                            <input type="text" id="slug" class="form-control slug" name="slug"
                                                value="<?php echo e(old('slug')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>

                                    <div class="row col-md-12">
                                        <div class="form-group col-md-4">
                                            <label>Category <span class="text-danger">*</span></label>
                                            <select name="category_id[]" class="form-control select2" id="category"
                                                multiple>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"
                                                        <?php echo e(in_array($category->id, old('category_id', [])) ? 'selected' : ''); ?>>
                                                        <?php echo e($category->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Sub Category</label>
                                            <select name="sub_category_id[]" class="form-control select2 sub_category"
                                                id="sub_category" multiple style="width: 100%">
                                                <option value="">Select Sub Category</option>
                                            </select>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Brand <span class="text-danger">*</span></label>
                                            <select name="brand_id[]" class="form-control select2" id="brand" multiple>
                                                <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($brand->id); ?>"
                                                        <?php echo e(in_array($brand->id, old('brand_id', [])) ? 'selected' : ''); ?>>
                                                        <?php echo e($brand->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <!-- Certifications Field -->
                                        <div class="form-group col-md-4">
                                            <label>Certifications <span class="text-danger">*</span></label>
                                            <select name="certification_id[]" class="form-control select2"
                                                id="certification" multiple>
                                                <?php $__currentLoopData = $certifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $certification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($certification->id); ?>"
                                                        <?php echo e(in_array($certification->id, old('certification_id', [])) ? 'selected' : ''); ?>>
                                                        <?php echo e($certification->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <!-- Company Field -->
                                        <div class="form-group col-md-4">
                                            <label>Company</label>
                                            <select name="company" class="form-control select2" id="company">
                                                <option value="" disabled selected>Select Company</option>
                                                <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($company->name); ?>"
                                                        <?php echo e(old('company') == $company->name ? 'selected' : ''); ?>>
                                                        <?php echo e($company->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <!-- Models Field -->
                                        
                                        <div class="form-group col-md-4">
                                            <label>Product HTS Code<span class="text-danger">*</span></label>
                                            <input type="text" id="product_hts" class="form-control product_hts"
                                                name="product_hts" value="<?php echo e(old('product_hts')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>

                                    </div>

                                    <div class="row col-md-12">
                                        <div class="form-group col-md-4">
                                            <label>Country</label>
                                            <select name="country" class="form-control select2" id="country">
                                                <option value="">Select Country</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->name); ?>"
                                                        <?php echo e(old('country') == $country->name ? 'selected' : ''); ?>>
                                                        <?php echo e($country->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($countries == null): ?>
                                                <div class="internet-error text-danger">No Internet Connection Found!</div>
                                            <?php endif; ?>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label>Product Commission <span class="text-danger">*</span></label>
                                            <div class="input-group">
                                                <input type="text" class="form-control" name="product_commission"
                                                    value="<?php echo e(old('product_commission')); ?>">

                                                <span class="input-group-addon"
                                                    style="
                                                border: 2px solid #ced4da;
                                                border-left: 0;
                                                display: flex;
                                                align-items: center;
                                                justify-content: center;
                                                width: 3rem;
                                                font-weight: bold;
                                            ">%</span>
                                                <div class="invalid-feedback"></div>
                                            </div>

                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Video Link</label>
                                            <input type="text" class="form-control" name="video_link"
                                                value="<?php echo e(old('video_link')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    <div class="row col-12">
                                        <div class="form-group col-md-4">
                                            <label>Number Of Use <span class="text-danger">*</span></label>
                                            <select name="product_use_status" class="form-control select2">
                                                <option value="" disabled selected>Select Number Of Use</option>
                                                <?php $__currentLoopData = $numberOfUses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $numberOfUse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($numberOfUse->name); ?>"
                                                        <?php echo e(old('product_use_status') == $numberOfUse->name ? 'selected' : ''); ?>>
                                                        <?php echo e($numberOfUse->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Sterilizations <span class="text-danger">*</span></label>
                                            <select name="sterilizations" class="form-control select2"
                                                id="sterilizations">
                                                <option value="" disabled selected>Select Sterilizations</option>
                                                <?php $__currentLoopData = $sterilizations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sterilization): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($sterilization->name); ?>"
                                                        <?php echo e(old('sterilizations') == $sterilization->name ? 'selected' : ''); ?>>
                                                        <?php echo e($sterilization->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label>Buyer Type <span class="text-danger">*</span></label>
                                            <select name="buyer_type" class="form-control select2">
                                                <option value="" disabled
                                                    <?php echo e(old('buyer_type') == '' ? 'selected' : ''); ?>>Select Buyer Type
                                                </option>
                                                <option value="Individual Customer"
                                                    <?php echo e(old('buyer_type') == ' Individual Customer' ? 'selected' : ''); ?>>
                                                    Individual Customer
                                                </option>
                                                <option value="Clinic"
                                                    <?php echo e(old('buyer_type') == 'Clinic' ? 'selected' : ''); ?>>Clinic
                                                </option>
                                                <option value="Private Hospital"
                                                    <?php echo e(old('buyer_type') == ' Private Hospital' ? 'selected' : ''); ?>>
                                                    Private Hospital
                                                </option>
                                                <option value="Govt. Hospital"
                                                    <?php echo e(old('buyer_type') == 'Govt. Hospital' ? 'selected' : ''); ?>>Govt.
                                                    Hospital
                                                </option>
                                                <option value="Reseller"
                                                    <?php echo e(old('buyer_type') == 'Reseller' ? 'selected' : ''); ?>>Reseller
                                                </option>
                                                <option value="Distributor"
                                                    <?php echo e(old('buyer_type') == 'Distributor' ? 'selected' : ''); ?>>Distributor
                                                </option>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <!-- Product Class Field -->
                                        <div class="form-group col-md-4">
                                            <label>Product Class <span class="text-danger">*</span></label>
                                            <select name="product_class" class="form-control select2">
                                                <option value="" disabled
                                                    <?php echo e(old('product_class') == '' ? 'selected' : ''); ?>>Select Product Class
                                                </option>
                                                <option value="Class A-1"
                                                    <?php echo e(old('product_class') == 'Class A-1' ? 'selected' : ''); ?>>Class A-1
                                                </option>
                                                <option value="Class B-2"
                                                    <?php echo e(old('product_class') == 'Class B-2' ? 'selected' : ''); ?>>Class B-2
                                                </option>
                                                <option value="Class C-3"
                                                    <?php echo e(old('product_class') == 'Class C-3' ? 'selected' : ''); ?>>Class C-3
                                                </option>
                                                <option value="Class D-4"
                                                    <?php echo e(old('product_class') == 'Class D-4' ? 'selected' : ''); ?>>Class D-4
                                                </option>
                                                <option value="Class E-5"
                                                    <?php echo e(old('product_class') == 'Class E-5' ? 'selected' : ''); ?>>Class E-5
                                                </option>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <!-- Main Material Field -->
                                        <div class="form-group col-md-4">
                                            <label>Main Material <span class="text-danger">*</span></label>
                                            <select name="material_id[]" class="form-control select2" multiple>
                                                <?php $__currentLoopData = $mianMaterials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mainMaterial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($mainMaterial->id); ?>"
                                                        <?php echo e(collect(old('material_id'))->contains($mainMaterial->id) ? 'selected' : ''); ?>>
                                                        <?php echo e($mainMaterial->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <!-- Supplier Name Field -->
                                        <div class="form-group col-md-4">
                                            <label>Supplier Name <span class="text-danger">*</span></label>
                                            <select id="supplier_name" name="supplier_name_display"
                                                class="form-control select2">
                                                <!-- Placeholder option -->
                                                <option value="" disabled>Select Supplier Name</option>
                                                <?php if(old('supplier_name_display')): ?>
                                                    <option value="<?php echo e(old('supplier_name_display')); ?>" selected>
                                                        <?php echo e(old('supplier_name')); ?></option>
                                                <?php endif; ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>

                                    <div class="row col-md-12">
                                        <!-- Supplier Id Field -->
                                        <div class="form-group col-md-4">
                                            <label>Supplier Id <span class="text-danger">*</span></label>
                                            <select id="supplier_id" name="supplier_id_display"
                                                class="form-control select2" disabled>
                                                <!-- Placeholder option -->
                                                <option value="" disabled>Select Supplier ID</option>
                                                <?php if(old('supplier_id_display')): ?>
                                                    <option value="<?php echo e(old('supplier_id_display')); ?>" selected>
                                                        <?php echo e(old('supplier_id')); ?></option>
                                                <?php endif; ?>
                                            </select>
                                        </div>

                                        <!-- Hidden fields for actual values -->
                                        <input type="hidden" id="supplier_name_hidden" name="supplier_name"
                                            value="<?php echo e(old('supplier_name')); ?>">
                                        <input type="hidden" id="supplier_id_hidden" name="supplier_id"
                                            value="<?php echo e(old('supplier_id')); ?>">

                                        <!-- Supplier Delivery Time Field -->
                                        <div class="form-group col-md-4">
                                            <label>Supplier Delivery Period <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="supplier_delivery_time"
                                                value="<?php echo e(old('supplier_delivery_time')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <!-- Delivery Period Field -->
                                        <div class="form-group col-md-4">
                                            <label>Delivery Period <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="delivery_period"
                                                value="<?php echo e(old('delivery_period')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>

                                        <div class="form-group col-md-4">
                                            <label>Warranty Period<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="warranty_period"
                                                value="<?php echo e(old('warranty_period')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>

                                    </div>

                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Short Description <span class="text-danger">*</span></label>
                                            <textarea name="short_description" cols="30" rows="10" class="form-control text-area-5"><?php echo e(old('short_description')); ?></textarea>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Long Description <span class="text-danger">*</span></label>
                                            <textarea name="long_description" cols="20" rows="50" class="long_description"><?php echo e(old('long_description')); ?></textarea>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-4">
                                            <label>Shelf Life / Expiry Period<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="self_life"
                                                value="<?php echo e(old('self_life')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Condition <span class="text-danger">*</span></label>
                                            <select name="product_condition" class="form-control select2" id="condition">
                                                <option value="" disabled selected>Select Conditions</option>
                                                <?php $__currentLoopData = $conditions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $condition): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($condition->name); ?>"
                                                        <?php echo e(old('product_condition') == $condition->name ? 'selected' : ''); ?>>
                                                        <?php echo e($condition->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label>Status <span class="text-danger">*</span></label>
                                            <select name="status" class="form-control">
                                                <option value="1">Active</option>
                                                <option value="0">Inactive</option>
                                            </select>
                                        </div>
                                    </div>
                                    <hr>
                                    
                                    <div class="row col-md-12">
                                        <h4 class="col-md-12">Tabs Content:</h4>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Tab 1 Heading</label>
                                            <input type="text" class="form-control" name="tab_1_heading"
                                                value="<?php echo e(old('tab_1_heading')); ?>">
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Tab 1 Content</label>
                                            <textarea name="tab_1_text" cols="20" rows="50" class="long_description"><?php echo e(old('tab_1_text')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Tab 2 Heading</label>
                                            <input type="text" class="form-control" name="tab_2_heading"
                                                value="<?php echo e(old('tab_2_heading')); ?>">
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Tab 2 Content</label>
                                            <textarea name="tab_2_text" cols="20" rows="50" class="long_description"><?php echo e(old('tab_2_text')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Tab 3 Heading</label>
                                            <input type="text" class="form-control" name="tab_3_heading"
                                                value="<?php echo e(old('tab_3_heading')); ?>">
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Tab 3 Content</label>
                                            <textarea name="tab_3_text" cols="20" rows="50" class="long_description"><?php echo e(old('tab_3_text')); ?></textarea>
                                        </div>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-12">
                                            <label>Tab 4 Heading</label>
                                            <input type="text" class="form-control" name="tab_4_heading"
                                                value="<?php echo e(old('tab_4_heading')); ?>">
                                        </div>
                                        <div class="form-group col-md-12">
                                            <label>Tab 4 Content</label>
                                            <textarea name="tab_4_text" cols="20" rows="50" class="long_description"><?php echo e(old('tab_4_text')); ?></textarea>
                                        </div>
                                    </div>

                                    
                                    <hr>
                                    <div class="row col-md-12">
                                        <h4 class="col-md-12">Taxes:</h4>
                                    </div>
                                    <div class="row col-md-12">
                                        <div class="form-group col-md-6">
                                            <label>Federal Tax<span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="federal_tax"
                                                value="<?php echo e(old('federal_tax')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                        <div class="form-group col-md-6">
                                            <label>Provincial Tax <span class="text-danger">*</span></label>
                                            <input type="text" class="form-control" name="provincial_tax"
                                                value="<?php echo e(old('provincial_tax')); ?>">
                                            <div class="invalid-feedback"></div>
                                        </div>
                                    </div>

                                    <div class="tax-fields">
                                        <div id="taxFields" class="row col-md-12">
                                            
                                            <div class="form-group col-md-6">
                                                <label>Tax/City<span class="text-danger">*</span></label>
                                                <select name="taxes[0][tax_per_city]" class="form-control select2">
                                                    <option value="" disabled
                                                        <?php echo e(old('taxes.0.tax_per_city') == null ? 'selected' : ''); ?>>Select
                                                        City</option>
                                                    <?php $__currentLoopData = [
            'Karachi',
            'Lahore',
            'Faisalabad',
            'Rawalpindi',
            'Multan',
            'Hyderabad',
            'Gujranwala',
            'Peshawar',
            'Quetta',
            'Islamabad',
            'Sargodha',
            'Sialkot',
            'Bahawalpur',
            'Sukkur',
            'Larkana',
            'Sheikhupura',
            'Mardan',
            'Gujrat',
            'Rahim Yar Khan',
            'Kasur',
            'Okara',
            'Sahiwal',
            'Wah Cantonment',
            'Dera Ghazi Khan',
            'Mingora',
            'Mirpur Khas',
            'Chiniot',
            'Nawabshah',
            'Kamoke',
            'Burewala',
            'Jhelum',
            'Sadiqabad',
            'Khanewal',
            'Hafizabad',
            'Kohat',
            'Jacobabad',
            'Shikarpur',
            'Muzaffargarh',
            'Abottabad',
            'Muridke',
            'Jhang',
            'Daska',
            'Mandi Bahauddin',
            'Khuzdar',
            'Pakpattan',
            'Tando Allahyar',
            'Vehari',
            'Gojra',
            'Mandi Bahauddin',
            'Turbat',
            'Dadu',
            'Bahawalnagar',
            'Khairpur',
            'Chishtian',
            'Charsadda',
            'Kandhkot',
            'Mianwali',
            'Tando Adam',
            'Dera Ismail Khan',
            'Kot Addu',
            'Nowshera',
            'Swabi',
            'Chakwal',
            'Tando Muhammad Khan',
            'Jaranwala',
            'Kandhkot',
            'Hasilpur',
            'Gojra',
            'Samundri',
            'Haveli Lakha',
            'Layyah',
            'Tank',
            'Chaman',
            'Bannu',
            'Haripur',
            'Attock',
            'Mansehra',
            'Lodhran',
            'Chakwal',
            'Chitral',
            'Kharan',
            'Kohlu',
            'Zhob',
            'Hub',
            'Gwadar',
            'Sibi',
        ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($city); ?>"
                                                            <?php echo e(old('taxes.0.tax_per_city') == $city ? 'selected' : ''); ?>>
                                                            <?php echo e($city); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-6">
                                                <label>Local Tax <span class="text-danger">*</span></label>
                                                <input type="text" class="form-control" name="taxes[0][local_tax]"
                                                    value="<?php echo e(old('taxes.0.local_tax')); ?>">
                                            </div>
                                        </div>
                                    </div>
                                    <!-- Append Button & Fields -->
                                    <div class="row col-md-12 mt-0 mb-2">
                                        <div class="col-md-12">
                                            <button type="button" class="btn btn-primary" id="addTaxBtn">
                                                Add Tax/City
                                            </button>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-md-12 text-center">
                                            <button type="button" class="btn btn-success submit-product"
                                                onclick="saveProduct()">Save</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

    <script>
        $(document).ready(function() {
            // Function to jump to the first error message
            function jumpToError() {
                // Find the first error message
                var firstError = $('.invalid-feedback').filter(':visible').first()

                if (firstError.length) {
                    // Scroll to the first error message
                    $('html, body').animate({
                        scrollTop: firstError.offset().top - 150 // Adjust offset as needed
                    }, 1000); // Animation duration in milliseconds
                }
            }

            // Call the function with a delay of 1000ms (1 second) on button click
            $('.submit-product').on('click', function() {
                setTimeout(function() {
                    jumpToError();
                    ckEditorValidation();
                }, 1000); // Delay of 1000 milliseconds
            });
        });
        $(document).ready(function() {
            function ckEditor() {
                // Collect CKEditor content and set it to respective textareas
                editors.forEach((editor, index) => {
                    let textarea = document.querySelectorAll('.long_description')[index];
                    textarea.value = editor.getData();
                });
            }

            let formData = {};

            // Restore form data from local storage
            function restoreFormData(savedData) {
                for (let key in savedData) {
                    let field = $('[name="' + key + '"]');
                    if (field.length) {
                        if (field.is('input[type="text"], textarea, input[type="hidden"]')) {
                            field.val(savedData[key]);
                        } else if (field.is('select')) {
                            field.val(savedData[key]).change();
                        } else if (field.is('input[type="radio"], input[type="checkbox"]')) {
                            field.each(function() {
                                if ($(this).val() === savedData[key]) {
                                    $(this).prop('checked', true);
                                }
                            });
                        }
                    }

                    // Restore image preview
                    if (key === 'thumbnailPreview' && savedData[key]) {
                        $('#preview-img').attr('src', savedData[key]);
                    }
                    // Pdf
                    if (key === 'pdfPreview' && savedData[key]) {
                        const pdfNameElement = $('#pdf-name');
                        const pdfPreviewContainer = $('#pdf-preview');

                        pdfNameElement.text(savedData[key]); // Set the file name
                        pdfPreviewContainer.show(); // Display the PDF preview container
                    }
                }
            }

            // Load form data from localStorage if available
            if (localStorage.getItem("formData")) {
                let savedData = JSON.parse(localStorage.getItem("formData"));
                console.log("Data restored:", savedData);
                restoreFormData(savedData);
            }

            // Update form data
            function updateFormData() {
                formData = {}; // Reset formData

                // Loop through each form field and collect values
                $('form input, form select, form textarea').each(function() {
                    let fieldName = $(this).attr('name');
                    let fieldValue = $(this).val();

                    if (fieldName) {
                        if ($(this).is(':radio, :checkbox')) {
                            if ($(this).is(':checked')) {
                                formData[fieldName] = fieldValue || '';
                            }
                        } else if (fieldValue !== '') {
                            formData[fieldName] = fieldValue;
                        }
                    }
                });

                // Collect taxes
                let taxes = [];
                $('form .taxes').each(function() {
                    let taxData = {};
                    let taxPerCity = $(this).find('.tax_per_city').val();
                    let localTax = $(this).find('.local_tax').val();

                    if (taxPerCity && localTax) {
                        taxData.tax_per_city = taxPerCity;
                        taxData.local_tax = localTax;
                        taxes.push(taxData);
                    }
                });

                if (taxes.length > 0) {
                    formData.taxes = taxes;
                }

                // Collect image preview
                const thumbnailSrc = $('#preview-img').attr('src');
                if (thumbnailSrc) {
                    formData.thumbnailPreview = thumbnailSrc;
                }
                // Upload pdf
                const pdfName = $('#pdf-name').text();
                if (pdfName && pdfName !== "No file selected") {
                    formData.pdfPreview = pdfName;
                }
                // Include CKEditor content
                ckEditor();
            }

            // Debounced form data save function
            let saveTimeout;

            function saveFormData() {
                clearTimeout(saveTimeout);
                saveTimeout = setTimeout(function() {
                    updateFormData();
                    $('#productForm').find('.is-invalid').removeClass('is-invalid');
                    $('#productForm').find('.invalid-feedback').removeClass('.invalid-feedback');
                    if (Object.keys(formData).length > 0) {
                        localStorage.setItem("formData", JSON.stringify(formData));

                        // Make AJAX request to autosave data
                        let formDataObj = new FormData($('#productForm')[0]);
                        const draftId = $('#draft_id').val();
                        if (draftId) {
                            formDataObj.append('draft_id', draftId);
                        }
                        formDataObj.append('_token', "<?php echo e(csrf_token()); ?>");

                        $.ajax({
                            url: "<?php echo e(url('admin/product/autosave')); ?>",
                            type: 'POST',
                            data: formDataObj,
                            processData: false,
                            contentType: false,
                            headers: {
                                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                            },
                            success: function(response) {
                                if (response.draft_id) {
                                    $('#draft_id').val(response.draft_id);
                                }
                                toastr.success('Data saved successfully');
                            },
                            error: function(xhr) {
                                console.log("error", xhr);

                            }
                        });
                    }
                }, 1000);
            }

            // Bind saveFormData to form fields' change/input events
            $('form input, form select, form textarea').on('change input', saveFormData);

            // Clear local storage if needed
            function clearLocalStorage() {
                localStorage.removeItem("formData");
                localStorage.removeItem("supplier_name_display");
                localStorage.removeItem("supplier_id_display");
            }

            // Final product save (no autosave)
            window.saveProduct = function saveProduct() {
                ckEditor(); // Ensure CKEditor content is collected
                // Create FormData and send the final save request
                let formDataObj = new FormData($('#productForm')[0]);
                const draftId = $('#draft_id').val();
                if (draftId) {
                    formDataObj.append('draft_id', draftId);
                }
                formDataObj.append('_token', "<?php echo e(csrf_token()); ?>");
                $.ajax({
                    url: "<?php echo e(route('product.store')); ?>",
                    type: 'POST',
                    data: formDataObj,
                    processData: false,
                    contentType: false,
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content'),
                    },
                    success: function() {
                        toastr.success("Product saved successfully!");

                        // Clear editor data
                        editors.forEach(editor => {
                            editor.setData('');
                        });

                        setTimeout(function() {
                            $('#draft_id').val('');
                            clearLocalStorage();
                            window.location.href = "<?php echo e(route('product.index')); ?>";
                        }, 2000);
                    },
                    error: function(xhr) {
                        if (xhr.status === 422) {
                            let errors = xhr.responseJSON.errors;
                            // console.log("error", errors);
                            $.each(errors, function(key, value) {
                                if (key.includes('taxes')) {
                                    toastr.error(value[0], 'Tax Error');
                                } else {
                                    $('form [name*="' + key + '"]').addClass('is-invalid')
                                        .siblings('.invalid-feedback').html(value[0]);
                                }
                            });
                        } else {
                            toastr.error("Failed to save product. Try again later.");
                        }
                    },
                    complete: function() {
                        $('form input, form select, form textarea').prop('disabled', false);
                    }
                });
            };
        });
    </script>

    <script>
        // Slug code
        (function($) {
            "use strict";
            $(document).ready(function() {
                $(".name").on("focusout", function(e) {
                    $(".slug").val(convertToSlug($(this).val()));
                })
            });
        })(jQuery);

        function convertToSlug(Text) {
            return Text
                .toLowerCase()
                .replace(/[^\w ]+/g, '')
                .replace(/ +/g, '-');
        }
        // Image perview code
        function previewThumbnailImage(event) {
            var reader = new FileReader();
            reader.onload = function() {
                var output = document.getElementById('preview-img');
                const imageData = reader.result;
                output.src = imageData;

                // Update the thumbnail preview in formData
                let savedData = JSON.parse(localStorage.getItem('formData')) || {};
                savedData.thumbnailPreview = imageData; // Store under a specific key
                localStorage.setItem('formData', JSON.stringify(savedData));
            }
            if (event.target.files[0]) { // Check if a file was selected
                reader.readAsDataURL(event.target.files[0]);
            }
        }

        function previewPDF(event) {
            const fileInput = event.target;
            const file = fileInput.files[0];

            if (file && file.type === "application/pdf") {
                const pdfPreview = document.getElementById('pdf-preview');
                const pdfName = document.getElementById('pdf-name');

                pdfName.textContent = file.name; // Show the file name
                pdfPreview.style.display = "block"; // Display the preview container
            } else {
                alert("Please upload a valid PDF file.");
                fileInput.value = ""; // Clear the input if the file is not a PDF
                document.getElementById('pdf-preview').style.display = "none";
            }
        }


        //   Upload pdf
        function previewPDF(event) {
            const fileInput = event.target;
            const file = fileInput.files[0];

            if (file && file.type === "application/pdf") {
                const reader = new FileReader();
                reader.onload = function() {
                    const pdfPreview = document.getElementById('pdf-preview');
                    const pdfName = document.getElementById('pdf-name');
                    const pdfData = reader.result;

                    pdfName.textContent = file.name; // Display file name
                    pdfPreview.style.display = "block"; // Show the preview container

                    // Save PDF data to localStorage
                    let savedData = JSON.parse(localStorage.getItem('formData')) || {};
                    savedData.pdfPreview = {
                        name: file.name,
                        data: pdfData
                    }; // Save name and base64 data
                    localStorage.setItem('formData', JSON.stringify(savedData));
                };
                reader.readAsDataURL(file); // Read file as Base64 data
            } else {
                alert("Please upload a valid PDF file.");
                fileInput.value = ""; // Clear the input if the file is not a PDF
                document.getElementById('pdf-preview').style.display = "none";

                // Remove any stored PDF data from localStorage
                let savedData = JSON.parse(localStorage.getItem('formData')) || {};
                delete savedData.pdfPreview;
                localStorage.setItem('formData', JSON.stringify(savedData));
            }
        }

        // Classic Editor Code
        let editors = [];

        document.querySelectorAll('.long_description').forEach((textarea, index) => {
            ClassicEditor
                .create(textarea)
                .then(editor => {
                    editors[index] = editor;

                    // Check if there's saved content in localStorage for this editor
                    let savedData = JSON.parse(localStorage.getItem(textarea.name));
                    if (savedData) {
                        // Restore CKEditor content from localStorage
                        editor.setData(savedData);
                    }
                    editor.model.document.on('change:data', () => {
                        let content = editor.getData();
                        localStorage.setItem(textarea.name, JSON.stringify(content));
                    });
                })
                .catch(error => {
                    console.error(error);
                });
        });
        // Show sub Categories against Category
        $(document).ready(function() {

            if ($('#category').val().length > 0) {
                var selectedCategories = $('#category').val();
                fetchSubCategories(selectedCategories, true); // true for initial load
            }

            // Handle category change event
            $('#category').change(function() {
                var selectedCategories = $(this).val();

                if (selectedCategories.length > 0) {
                    fetchSubCategories(selectedCategories, true);
                } else {
                    resetSubCategoryDropdown();
                }
            });

            function fetchSubCategories(categoryIds, isInitialLoad) {
                $.ajax({
                    url: '<?php echo e(route('category.subCategories')); ?>',
                    type: 'GET',
                    data: {
                        category_ids: categoryIds
                    },
                    success: function(response) {
                        console.log("populate", response);

                        populateSubCategoryDropdown(response, isInitialLoad);
                    },
                    error: function(xhr) {
                        console.error('Error fetching subcategories:', xhr);
                    }
                });
            }

            function populateSubCategoryDropdown(response, isInitialLoad) {
                $('#sub_category').empty();
                var oldSubCategories = <?php echo json_encode(old('sub_category_id', []), 512) ?>;
                var savedSubCategories = JSON.parse(localStorage.getItem('selectedSubCategories')) || [];
                var selectedSubCategories = isInitialLoad ? new Set([...oldSubCategories, ...savedSubCategories]) :
                    new Set();
                if (response.length > 0) {
                    response.forEach(function(subCategory) {
                        var isSelected = selectedSubCategories.has(String(subCategory.id)) ? 'selected' :
                            '';
                        $('#sub_category').append(
                            '<option value="' + subCategory.id + '" ' + isSelected + '>' +
                            subCategory.name + '</option>'
                        );
                    });

                    $('#sub_category').prop('disabled', false);
                } else {
                    $('#sub_category').append('<option value="">No Sub Category Available</option>');
                    $('#sub_category').prop('disabled', true);
                }

                // Save selected subcategories on initial load
                if (isInitialLoad) {
                    $('#sub_category').val([...selectedSubCategories]);
                }

                // Trigger change for Select2 or other plugins
                $('#sub_category').trigger('change');
            }

            function resetSubCategoryDropdown() {
                $('#sub_category').empty();
                $('#sub_category').append('<option value="">Select Sub Category</option>');
                $('#sub_category').prop('disabled', true);
            }

            // Save selected subcategories to local storage on change
            $('#sub_category').change(function() {
                var selectedValues = $(this).val();
                localStorage.setItem('selectedSubCategories', JSON.stringify(selectedValues || []));
            });
        });



        //################ Get Supplier Name ############
        let oldSupplierName = "<?php echo e(old('supplier_name_display')); ?>";
        let oldSupplierId = "<?php echo e(old('supplier_id_display')); ?>";

        // Fetch suppliers via AJAX and populate the dropdown
        $.ajax({
            url: "<?php echo e(route('getSuppliers')); ?>",
            type: 'GET',
            success: function(data) {
                let supplierNameDropdown = $('#supplier_name');
                supplierNameDropdown.empty().append(
                    '<option value="" disabled selected>Select Supplier Name</option>'
                );

                // Populate the supplier_name dropdown with options
                data.forEach(function(supplier) {
                    supplierNameDropdown.append(
                        `<option value="${supplier.id}" ${oldSupplierName == supplier.id || localStorage.getItem("supplier_name_display") == supplier.id ? 'selected' : ''}>${supplier.name}</option>`
                    );
                });

                // Check if there's an old value or stored value in localStorage for supplier_name
                let savedSupplierName = localStorage.getItem("supplier_name_display") || oldSupplierName;
                if (savedSupplierName) {
                    supplierNameDropdown.val(savedSupplierName).trigger('change');
                }
            },
            error: function(error) {
                console.log('Error fetching suppliers:', error);
            }
        });

        // Handle change event on Supplier Name dropdown
        $('#supplier_name').change(function() {
            let selectedSupplierId = $(this).val();
            let supplierIdDropdown = $('#supplier_id');

            if (selectedSupplierId) {
                // Find the selected supplier from the fetched data
                $.ajax({
                    url: "<?php echo e(route('getSuppliers')); ?>",
                    type: 'GET',
                    success: function(data) {
                        let selectedSupplier = data.find(supplier => supplier.id == selectedSupplierId);
                        if (selectedSupplier) {
                            supplierIdDropdown.empty().append(
                                `<option value="${selectedSupplier.supplier_id}" ${oldSupplierId == selectedSupplier.supplier_id || localStorage.getItem("supplier_id_display") == selectedSupplier.supplier_id ? 'selected' : ''}>${selectedSupplier.supplier_id}</option>`
                            );
                            supplierIdDropdown.prop('disabled', true);

                            // Store supplier name and ID in hidden fields
                            $('#supplier_name_hidden').val(selectedSupplier.name);
                            $('#supplier_id_hidden').val(selectedSupplier.supplier_id);

                            // Save selected supplier details to localStorage
                            localStorage.setItem("supplier_name_display", selectedSupplier.id);
                            localStorage.setItem("supplier_id_display", selectedSupplier.supplier_id);
                        }
                    },
                    error: function(error) {
                        console.log('Error fetching suppliers:', error);
                    }
                });
            }
        });

        // ############# Add Taxes #############
        function addTax() {
            let taxCount = $('.tax-fields').length;
            let variantFieldHTML = `
    <div class="tax-fields border mt-1 col-md-12 mb-2">
        <div class="d-flex justify-content-end mt-1 mb-0">
            <i class="fa fa-trash btn btn-danger btn-sm removeVariantBtn"></i>
        </div>
        <div class="row">
            <div class="form-group col-md-6 col-sm-12">
                <label>Tax/City<span class="text-danger">*</span></label>
                <select name="taxes[${taxCount}][tax_per_city]" class="form-control select2">
                    <option value="" disabled selected>Select City</option>
                    <option value="Karachi">Karachi</option>
                    <option value="Lahore">Lahore</option>
                    <option value="Faisalabad">Faisalabad</option>
                    <option value="Rawalpindi">Rawalpindi</option>
                    <option value="Multan">Multan</option>
                    <option value="Hyderabad">Hyderabad</option>
                    <option value="Gujranwala">Gujranwala</option>
                    <option value="Peshawar">Peshawar</option>
                    <option value="Quetta">Quetta</option>
                    <option value="Islamabad">Islamabad</option>
                    <option value="Sargodha">Sargodha</option>
                    <option value="Sialkot">Sialkot</option>
                    <option value="Bahawalpur">Bahawalpur</option>
                    <option value="Sukkur">Sukkur</option>
                    <option value="Larkana">Larkana</option>
                    <option value="Sheikhupura">Sheikhupura</option>
                    <option value="Mardan">Mardan</option>
                    <option value="Gujrat">Gujrat</option>
                    <option value="Rahim Yar Khan">Rahim Yar Khan</option>
                    <option value="Kasur">Kasur</option>
                    <option value="Okara">Okara</option>
                    <option value="Sahiwal">Sahiwal</option>
                    <option value="Wah Cantonment">Wah Cantonment</option>
                    <option value="Dera Ghazi Khan">Dera Ghazi Khan</option>
                    <option value="Mingora">Mingora</option>
                    <option value="Mirpur Khas">Mirpur Khas</option>
                    <option value="Chiniot">Chiniot</option>
                    <option value="Nawabshah">Nawabshah</option>
                    <option value="Kamoke">Kamoke</option>
                    <option value="Burewala">Burewala</option>
                    <option value="Jhelum">Jhelum</option>
                    <option value="Sadiqabad">Sadiqabad</option>
                    <option value="Khanewal">Khanewal</option>
                    <option value="Hafizabad">Hafizabad</option>
                    <option value="Kohat">Kohat</option>
                    <option value="Jacobabad">Jacobabad</option>
                    <option value="Shikarpur">Shikarpur</option>
                    <option value="Muzaffargarh">Muzaffargarh</option>
                    <option value="Abottabad">Abottabad</option>
                    <option value="Muridke">Muridke</option>
                    <option value="Jhang">Jhang</option>
                    <option value="Daska">Daska</option>
                    <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                    <option value="Khuzdar">Khuzdar</option>
                    <option value="Pakpattan">Pakpattan</option>
                    <option value="Tando Allahyar">Tando Allahyar</option>
                    <option value="Vehari">Vehari</option>
                    <option value="Gojra">Gojra</option>
                    <option value="Mandi Bahauddin">Mandi Bahauddin</option>
                    <option value="Turbat">Turbat</option>
                    <option value="Dadu">Dadu</option>
                    <option value="Bahawalnagar">Bahawalnagar</option>
                    <option value="Khairpur">Khairpur</option>
                    <option value="Chishtian">Chishtian</option>
                    <option value="Charsadda">Charsadda</option>
                    <option value="Kandhkot">Kandhkot</option>
                    <option value="Mianwali">Mianwali</option>
                    <option value="Tando Adam">Tando Adam</option>
                    <option value="Dera Ismail Khan">Dera Ismail Khan</option>
                    <option value="Kot Addu">Kot Addu</option>
                    <option value="Nowshera">Nowshera</option>
                    <option value="Swabi">Swabi</option>
                    <option value="Chakwal">Chakwal</option>
                    <option value="Tando Muhammad Khan">Tando Muhammad Khan</option>
                    <option value="Jaranwala">Jaranwala</option>
                    <option value="Kandhkot">Kandhkot</option>
                    <option value="Hasilpur">Hasilpur</option>
                    <option value="Gojra">Gojra</option>
                    <option value="Samundri">Samundri</option>
                    <option value="Haveli Lakha">Haveli Lakha</option>
                    <option value="Layyah">Layyah</option>
                    <option value="Tank">Tank</option>
                    <option value="Chaman">Chaman</option>
                    <option value="Bannu">Bannu</option>
                    <option value="Haripur">Haripur</option>
                    <option value="Attock">Attock</option>
                    <option value="Mansehra">Mansehra</option>
                    <option value="Lodhran">Lodhran</option>
                    <option value="Chakwal">Chakwal</option>
                    <option value="Chitral">Chitral</option>
                    <option value="Kharan">Kharan</option>
                    <option value="Kohlu">Kohlu</option>
                    <option value="Zhob">Zhob</option>
                    <option value="Hub">Hub</option>
                    <option value="Gwadar">Gwadar</option>
                    <option value="Sibi">Sibi</option>
                </select>
            </div>
            <div class="form-group col-md-6 col-sm-12">
                <label>Local Tax <span class="text-danger">*</span></label>
                <input type="text" class="form-control" name="taxes[${taxCount}][local_tax]"
                    value="">
            </div>
        </div>
    </div>
    `;
            $('#taxFields').append(variantFieldHTML);
            $('.select2').select2();
        }

        // Remove variant field
        $(document).on('click', '.removeVariantBtn', function() {

            $(this).closest('.tax-fields').remove();
        });
        // Event listener for Add Variant button
        $('#addTaxBtn').click(function() {
            addTax();
        });

        function ckEditorValidation() {



                // Collect CKEditor content and set it to respective textareas
                editors.forEach((editor, index) => {
                    let textarea = document.querySelectorAll('[name="long_description"]')[index];
                    textarea.value = editor.getData();

                    // Find the feedback element (span) related to this textarea
                    let feedback = textarea.closest('.form-group').querySelector('.invalid-feedback');

                    // Check if the field is empty
                    if (!textarea.value.trim()) {
                        textarea.classList.add('is-invalid'); // Add invalid class
                        feedback.textContent =
                        'The long description field is required.'; // Set error message
                        feedback.style.display = 'block';
                    } else {
                        textarea.classList.remove('is-invalid'); // Remove invalid class
                        feedback.textContent = ''; // Clear error message
                        feedback.style.display = 'none';
                    }
                });
            }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/admin/product/create.blade.php ENDPATH**/ ?>