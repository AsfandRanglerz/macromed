<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="https://macromed.com.pk/"> <img alt="image" src="<?php echo e(asset('public/admin/assets/images/logo-macromed.png')); ?>"
                    style="width: 40%" />
            </a>
        </div>
        <ul class="sidebar-menu">
            <li class="menu-header">Main</li>
            
            <li class="dropdown <?php echo e(request()->is('sales-agent/dashboard') ? 'active' : ''); ?>">
                <a href="<?php echo e(url('/sales-agent/dashboard')); ?>" class="nav-link"><span><i
                            data-feather="home"></i>Dashboard</span></a>
            </li>
            
            <li class="dropdown <?php echo e(request()->is('sales-agent/user-order*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('user-order.index')); ?>" class="nav-link padding" style="padding-left: 27px">
                    <span> <i data-feather="shopping-cart"></i>
                        Orders</span>
                    <div id="orderUserCounter"
                        class="badge <?php echo e(request()->is('sales-agent/user-order*') ? 'bg-white text-dark' : 'bg-primary text-white'); ?> rounded-circle ">
                    </div>
                </a>
            </li>
            
            <li class="dropdown <?php echo e(request()->is('sales-agent/user-reports*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('user-reports.index')); ?>" class="nav-link">
                    <span><i data-feather="file-text"></i>Reports</span>
                </a>
            </li>

             
             <li class="dropdown <?php echo e(request()->is('sales-agent/withdraw-request*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('user-request.index')); ?>" class="nav-link" style="padding-left:10px;">
                    <span><i class="fas fa-coins"></i>With Drawal Request</span>
                </a>
            </li>
            
            <li class="dropdown <?php echo e(request()->is('sales-agent/agentNotes*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agentNotes.index')); ?>"
                    class="nav-link <?php echo e(request()->is('sales-agent/agentNotes*') ? 'text-white' : ''); ?>">
                    <span> <i data-feather="file"></i>Private Notes</span>
                </a>
            </li>
            
            </li>
        </ul>
    </aside>
</div>
<?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/salesagent/common/side_menu.blade.php ENDPATH**/ ?>