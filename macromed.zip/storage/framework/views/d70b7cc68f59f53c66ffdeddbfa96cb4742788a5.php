<?php $__env->startSection('title', 'Profile'); ?>
<?php $__env->startSection('content'); ?>

    <!-- Main Content -->
    <div class="main-content">
        <section class="section">
            <div class="section-body">
                <div class="row mt-sm-4">
                    <div class="col-12 col-md-12 col-lg-12">
                        <div class="card">
                            <div class="padding-20">
                                <ul class="nav nav-tabs" id="myTab2" role="tablist">
                                    <li class="nav-item">
                                        <a class="nav-link" id="home-tab2" data-toggle="tab" href="#about" role="tab"
                                            aria-selected="false">About</a>
                                    </li>
                                    <li class="nav-item">
                                        <a class="nav-link active" id="profile-tab2" data-toggle="tab" href="#settings"
                                            role="tab" aria-selected="true">Setting</a>
                                    </li>
                                </ul>
                                <div class="tab-content tab-bordered" id="myTab3Content">
                                    <div class="tab-pane fade" id="about" role="tabpanel" aria-labelledby="home-tab2">
                                        <div class="row">
                                            <div class="col-md-3 col-6 b-r">
                                                <strong>Full Name</strong>
                                                <br>
                                                <p class="text-muted"><?php echo e($data->name); ?></p>
                                            </div>
                                            <div class="col-md-3 col-6 b-r">
                                                <strong>Mobile</strong>
                                                <br>
                                                <p class="text-muted"><?php echo e($data->phone); ?></p>
                                            </div>
                                            <div class="col-md-3 col-6 b-r">
                                                <strong>Email</strong>
                                                <br>
                                                <p class="text-muted"><?php echo e($data->email); ?></p>
                                            </div>

                                        </div>
                                    </div>
                                    <div class="tab-pane fade active show" id="settings" role="tabpanel"
                                        aria-labelledby="profile-tab2">
                                        <form method="post" action="<?php echo e(url('sales-agent/update-profile')); ?>"
                                            enctype="multipart/form-data">
                                            <?php echo csrf_field(); ?>
                                            <div class="card-header">
                                                <h4>Edit Profile</h4>
                                            </div>
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Name</label>
                                                        <input type="text" name="name" value="<?php echo e($data->name); ?>"
                                                            class="form-control">
                                                    </div>
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Email</label>
                                                        <input type="email" name="email" value="<?php echo e($data->email); ?>"
                                                            class="form-control">

                                                    </div>

                                                </div>
                                                <div class="row">
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Profile Image</label>
                                                        <div class="custom-file">
                                                            <input type="file" name="image" class="custom-file-input"
                                                                id="customFile">
                                                            <label class="custom-file-label" for="customFile">Choose
                                                                file</label>
                                                        </div>
                                                        <img src="<?php echo e(asset('public/' . $data->image)); ?>" alt="Profile Image"
                                                            width="100" class="mt-2">
                                                        <div class="invalid-feedback"></div>
                                                    </div>
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Phone</label>
                                                        <input type="number" name="phone" value="<?php echo e($data->phone); ?>"
                                                            class="form-control">

                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Country</label>
                                                        <input type="text" name="country"
                                                            value="<?php echo e(explode(',', $data->country)[1]); ?>"
                                                            class="form-control" disabled>
                                                    </div>
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>State</label>
                                                        <input type="text" name="state"
                                                            value="<?php echo e(explode(',', $data->state)[1]); ?>" class="form-control"
                                                            disabled>
                                                    </div>
                                                </div>

                                                <div class="row">
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>City</label>
                                                        <input type="text" name="city" value="<?php echo e($data->city); ?>"
                                                            class="form-control" disabled>
                                                    </div>
                                                    <div class="form-group col-md-6 col-12">
                                                        <label>Location</label>
                                                        <input type="text" name="location" value="<?php echo e($data->location); ?>"
                                                            class="form-control">

                                                    </div>
                                                </div>

                                                <h4>Account Details</h4>
                                                <?php if(isset($data->salesAgent) && count($data->salesAgent) > 0): ?>
                                                    <?php $__currentLoopData = $data->salesAgent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <div class="row">
                                                            <div class="form-group col-md-4 col-12">
                                                                <label>Account Name</label>
                                                                <input type="text" name="account_name"
                                                                    value="<?php echo e($agent->account_name); ?>"
                                                                    class="form-control">
                                                            </div>

                                                            <div class="form-group col-md-4 col-12">
                                                                <label>Account Holder Name</label>
                                                                <input type="text" name="account_holder_name"
                                                                    value="<?php echo e($agent->account_holder_name); ?>"
                                                                    class="form-control">
                                                            </div>

                                                            <div class="form-group col-md-4 col-12">
                                                                <label>Account Number</label>
                                                                <input type="text" name="account_number"
                                                                    value="<?php echo e($agent->account_number); ?>"
                                                                    class="form-control">

                                                            </div>
                                                        </div>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                <h4>Change Password</h4>


                                                        <div class="row">
                                                            <div class="form-group col-md-4 col-12">
                                                                <label>Old Password</label>
                                                                <input type="password" id="old_password" name="old_password"

                                                                    class="form-control">
                                                                    <span class="fa fa-eye-slash position-absolute toggle-password" data-target="old_password"
                                                                    style="top: 3.18rem; right: 1.4rem; cursor: pointer;"></span>
                                                                </div>

                                                                <div class="form-group col-md-4 col-12">
                                                                    <label>New Password</label>
                                                                    <input type="password" id="new_password" name="new_password"

                                                                    class="form-control">
                                                                    <span class="fa fa-eye-slash position-absolute toggle-password" data-target="new_password"
                                                                    style="top: 3.18rem; right: 1.4rem; cursor: pointer;"></span>
                                                            </div>


                                                        </div>

                                            </div>
                                            <div class="card-footer text-center">
                                                <button type="submit" class="btn btn-primary">Save Changes</button>
                                            </div>
                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<script>
    <?php if($errors->any()): ?>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    toastr.error('<?php echo e($error); ?>');
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    </script>

    <script>
        document.querySelectorAll('.toggle-password').forEach(icon => {
            icon.addEventListener('click', function () {
                const passwordField = document.getElementById(this.getAttribute('data-target'));
                const type = passwordField.getAttribute('type') === 'password' ? 'text' : 'password';
                passwordField.setAttribute('type', type);

                // Toggle eye icon
                this.classList.toggle('fa-eye-slash');
                this.classList.toggle('fa-eye');
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('salesagent.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\macromed\macromed\resources\views/salesagent/auth/profile.blade.php ENDPATH**/ ?>