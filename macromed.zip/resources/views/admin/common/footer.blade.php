<footer class="main-footer">
    <div class="footer-left">
        <p>Powered By <a href="https://macromed.com.pk/" style="color:#fff !important">Macromed</a></p>
    </div>
    <div class="footer-right">
    </div>
</footer>
